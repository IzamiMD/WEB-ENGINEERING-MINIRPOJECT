<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vpmsdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Parking Space</title>
    <link rel="stylesheet" href="ManageParking.css">
    <script src="qrcodejs-master/qrcode.min.js"></script> <!-- Include qrcodejs library -->
    <script defer src="ManageParking.js"></script>
</head>
<body>
    <div class="container">    
        <div class="right">
            <div id="manage-parking" class="section">
                <button class="nav-button" onclick="history.back()">Back</button>
                <h1>Manage Parking</h1>
                <section class="overall">
                    <div class="container1">
                        <section>
                            <h2>Create New Parking</h2>
                            <form id="createParkingForm" method="post" action="ManageParking.php?action=create">
                                <label for="status">Status:</label>
                                <input type="text" id="status" name="status" required>
                                <label for="location">Location:</label>
                                <select id="location" name="location" required>
                                    <option value="A1">A1</option>
                                    <option value="A2">A2</option>
                                    <option value="A3">A3</option>
                                    <option value="B1">B1</option>
                                    <option value="B2">B2</option>
                                    <option value="B3">B3</option>
                                    <option value="B4">B4</option>
                                </select>
                                <button type="submit">Submit</button>
                            </form>
                        </section>
                        <section>
                            <h2>Delete Parking</h2>
                            <form id="deleteParkingForm" action="ManageParking.php?action=delete" method="POST">
                                <label for="deleteId">Parking ID:</label>
                                <input type="text" id="deleteId" name="deleteId" required>
                                <button type="submit">Delete</button>
                            </form>
                        </section>

                        <section>
                            <h2>Update Parking Status</h2>
                            <form id="updateStatusForm" action="ManageParking.php?action=update" method="POST">
                                <label for="statusId">Parking ID:</label>
                                <input type="text" id="statusId" name="statusId" required>
                                <label for="newStatus">New Status:</label>
                                <input type="text" id="newStatus" name="newStatus" required>
                                <button type="submit">Update Status</button>
                            </form>
                        </section>
                    </div>
                    
                    <div>
                        <h2>Parking Space Information</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>Parking ID</th>
                                    <th>Location</th>
                                    <th>Status</th>
                                    <th>QR Code</th>
                                </tr>
                            </thead>
                            <tbody id="parkingTableBody">
                                <?php
                                $sql = "SELECT parking_id, location, status FROM parking";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . $row['parking_id'] . "</td>";
                                        echo "<td>" . $row['location'] . "</td>";
                                        echo "<td>" . $row['status'] . "</td>";
                                        echo "<td><div id='qrcode-" . $row['parking_id'] . "'></div></td>";
                                        echo "<script type='text/javascript'>new QRCode(document.getElementById('qrcode-" . $row['parking_id'] . "'), { text: 'Parking ID: " . $row['parking_id'] . "', width: 100, height: 100 });</script>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='4'>No parking spaces available</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>
    </div>

    <div id="successModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeModal()">&times;</span>
            <p id="successMessage"></p>
        </div>
    </div>
</body>
<footer>
    
</footer>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_GET['action'] === 'create') {
        $status = $_POST['status'];
        $location = $_POST['location'];

        $sql = "SELECT MAX(parking_id) AS max_id FROM parking";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $newId = $row['max_id'] + 1;

        $sql = "INSERT INTO parking (parking_id, location, status) VALUES ('$newId', '$location', '$status')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('New parking created successfully');</script>";
        } else {
            echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
        }
    } elseif ($_GET['action'] === 'delete') {
        $deleteId = $_POST['deleteId'];

        $sql = "DELETE FROM parking WHERE parking_id='$deleteId'";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Record deleted successfully');</script>";
        } else {
            echo "<script>alert('Error deleting record: " . $conn->error . "');</script>";
        }
    } elseif ($_GET['action'] === 'update') {
        $statusId = $_POST['statusId'];
        $newStatus = $_POST['newStatus'];

        if ($stmt = $conn->prepare('UPDATE parking SET status=? WHERE parking_id=?')) {
            $stmt->bind_param('ss', $newStatus, $statusId);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                echo "<script>alert('Status updated successfully');</script>";
            } else {
                echo "<script>alert('Error or no change in status: " . $stmt->error . "');</script>";
            }

            $stmt->close();
        } else {
            echo "<script>alert('Error preparing statement: " . $conn->error . "');</script>";
        }
    }
    $conn->close();
}
?>
