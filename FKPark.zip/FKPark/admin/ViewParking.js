document.addEventListener('DOMContentLoaded', function() {
    fetch('get_parking_data.php')
        .then(response => response.json())
        .then(data => {
            console.log('Data received:', data); 
            displayData(data);
        })
        .catch(error => console.error('Error:', error));
});

function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.style.display = 'none';
    });
    document.getElementById(sectionId).style.display = 'block';
}

window.onload = () => {
    showSection('view-parking-slot');
    fetchDataAndUpdateDashboard();
}

function filterByLocation() {
    const location = document.getElementById('location-select').value;
    fetchAndUpdateData(location);
}

function fetchAndUpdateData(location = '') {
    const url = 'get_parking_data.php';
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (location) {
                data = data.filter(item => item.location === location);
            }
            console.log('Filtered data:', data); // Debug log
            displayData(data);
        })
        .catch(error => console.error('Error:', error));
}

function displayData(data) {
    const tableBody = document.getElementById('parking-data');
    tableBody.innerHTML = '';

    if (data.error) {
        tableBody.innerHTML = `<tr><td colspan="5">${data.error}</td></tr>`;
        return;
    }

    data.forEach(item => {
        const row = document.createElement('tr');
    
        const cellId = document.createElement('td');
        cellId.textContent = item.parking_id;
        row.appendChild(cellId);

        const cellSpace = document.createElement('td');
        cellSpace.textContent = item.location;
        row.appendChild(cellSpace);

        const cellStatus = document.createElement('td');
        cellStatus.textContent = item.status;
        row.appendChild(cellStatus);

        const cellAvailableSlot = document.createElement('td');
        const slotContainer = document.createElement('div');
        slotContainer.style.display = 'flex';
        slotContainer.style.justifyContent = 'space-around';
    
        const timeSlots = [
            '08:00', '09:00', '10:00', '11:00',
            '12:00', '13:00', '14:00', '15:00', '16:00'
        ];
    
        timeSlots.forEach(time => {
            const slotDiv = document.createElement('div');
            slotDiv.style.flex = '1';
            slotDiv.style.textAlign = 'center';
            slotDiv.style.padding = '8px';
            slotDiv.style.margin = '2px';
            slotDiv.style.borderRadius = '4px';
            const slotData = detectTimeSlot(item.slots, time);
            console.log('Slot data for time', time, slotData); // Debug log
            slotDiv.style.backgroundColor = slotData && slotData.confirmed ? 'red' : 'lightgray';
            slotDiv.textContent = time;
            slotDiv.style.color = slotData && slotData.confirmed ? 'white' : 'black';
            slotContainer.appendChild(slotDiv);
        });
    
        cellAvailableSlot.appendChild(slotContainer);
        row.appendChild(cellAvailableSlot);

        const cellActions = document.createElement('td');
        
        const updateButton = document.createElement('button');
        updateButton.textContent = 'Update';
        updateButton.className = 'primary';
        updateButton.onclick = () => window.location.href = 'ManageParking.php';
        cellActions.appendChild(updateButton);

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.className = 'danger';
        deleteButton.onclick = () => window.location.href = 'ManageParking.php';
        cellActions.appendChild(deleteButton);

        row.appendChild(cellActions);

        tableBody.appendChild(row);
    });
}


function detectTimeSlot(slots, time) {
    return slots.find(slot => slot.time_slot && slot.time_slot.startsWith(time));
}
