<?php
include 'db.php';

$sql = "SELECT parking_id, location, status FROM parking";
$result = $conn->query($sql);
$spaces = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $spaces[] = $row;
    }
    echo json_encode($spaces);
} else {
    echo json_encode([]);
}

$conn->close();
?>
