<?php
include 'db.php';

$deleteId = $_POST['deleteId'];

$sql = "DELETE FROM parking WHERE parking_id='$deleteId'";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
