<?php
include 'db.php';

$status = $_POST['status'];
$location = $_POST['location'];

// Generate a new parking ID based on the highest current ID
$sql = "SELECT MAX(parking_id) AS max_id FROM parking";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$newId = $row['max_id'] + 1;

$sql = "INSERT INTO parking (parking_id, location, status) VALUES ('$newId', '$location', '$status')";
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
