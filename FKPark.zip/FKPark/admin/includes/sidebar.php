 <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"><i class="menu-icon fa fa-laptop"></i>User Dashboard </a>
                    </li>
                    <li>
                        <a href="admin-dashboard.php"> <i class="menu-icon ti-user"></i>Admin Dashboard</a>
                    </li>
                   
                   
                    
                    <li>
                        <a href="add-vehicle.php"> <i class="menu-icon ti-email"></i>Register Vehicle </a>
                    </li>
                    <li>
                        <a href="signup.php"> <i class="menu-icon ti-user"></i>Register Student</a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <ul class="sub-menu children dropdown-menu">
                            
                           
                        </li>

                        </ul>
                    </li>
                    

                    <li>
                        <a href="reg-users.php"> <i class="menu-icon ti-user"></i>Registered Users </a>
                    </li>
                    <li>
                        <a href="view-vehicles.php"> <i class="menu-icon ti-user"></i>Registered Vehicles </a>
                    </li>
                    <li>
                        <a href="ManageParking.php"> <i class="menu-icon ti-user"></i>Manage Parking</a>
                    </li>
                    <li>
                        <a href="ViewParkingAdmin.php"> <i class="menu-icon ti-user"></i>View Parking Slot</a>
                    </li>
                    
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>