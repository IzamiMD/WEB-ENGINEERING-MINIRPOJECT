<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vpmsdb"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT p.parking_id, p.location, p.status,
        GROUP_CONCAT(JSON_OBJECT('time_slot', pb.time_slot, 'confirmed', pb.Confirmed)) AS slots
        FROM parking p
        LEFT JOIN parkingbooking pb ON p.parking_id = pb.parking_id
        GROUP BY p.parking_id";

$result = $conn->query($sql);
$response = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $slots = json_decode('[' . $row['slots'] . ']', true);
        $slots = array_map(function($slot) {
            return [
                'time_slot' => $slot['time_slot'] ?? null,
                'confirmed' => $slot['confirmed'] ?? false
            ];
        }, $slots);

        $response[] = [
            'parking_id' => $row['parking_id'],
            'location' => $row['location'],
            'status' => $row['status'],
            'slots' => $slots,
        ];
    }
} else {
    $response['error'] = "No parking data found.";
}

$conn->close();
echo json_encode($response);
?>
