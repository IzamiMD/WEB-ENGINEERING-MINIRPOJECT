<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsaid']==0)) {
  header('location:logout.php');
} else {
  if (isset($_POST['submit'])) {
    $parkingnumber = mt_rand(100000000, 999999999);
    $catename = $_POST['catename'];
    $vehcomp = $_POST['vehcomp'];
    $vehreno = $_POST['vehreno'];
    $ownername = $_POST['ownername'];
    $ownercontno = $_POST['ownercontno'];
    $enteringtime = $_POST['enteringtime'];

    $query = mysqli_query($con, "insert into tblvehicle(ParkingNumber, VehicleCategory, VehicleCompanyname, RegistrationNumber, OwnerName, OwnerContactNumber) value('$parkingnumber', '$catename', '$vehcomp', '$vehreno', '$ownername', '$ownercontno')");
    if ($query) {
      echo "<script>alert('Vehicle Entry Detail has been added');</script>";
      echo "<script>window.location.href ='manage-incomingvehicle.php'</script>";
    } else {
      echo "<script>alert('Something Went Wrong. Please try again.');</script>";       
    }
  }
?>
<!doctype html>
<html class="no-js" lang="">
<head>
  <title>VPMS - Add Vehicle</title>
  <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
  <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
  <link rel="stylesheet" href="../admin/assets/css/cs-skin-elastic.css">
  <link rel="stylesheet" href="../admin/assets/css/style.css">
  <link href="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/jqvmap@1.5.1/dist/jqvmap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/weathericons@2.1.0/css/weather-icons.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.css" rel="stylesheet" />
  
  <!--ADMINISTRATOR DASHBOARD LINK-->
  <link rel="stylesheet" href="../css/admin_styles.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script defer src="../js/admin_dashboard.js"></script>
  <!--ADMINISTRATOR DASHBOARD LINK-->
  
  <style>
    #weatherWidget .currentDesc { color: #ffffff!important; }
    .traffic-chart { min-height: 335px; }
    #flotPie1 { height: 150px; }
    #flotPie1 td { padding: 3px; }
    #flotPie1 table { top: 20px!important; right: -10px!important; }
    .chart-container { display: table; min-width: 270px; text-align: left; padding-top: 10px; padding-bottom: 10px; }
    #flotLine5 { height: 105px; }
    #flotBarChart { height: 150px; }
    #cellPaiChart { height: 160px; }
  </style>
  
</head>

<body>
<?php include_once('includes/sidebar.php'); ?>
<!-- Right Panel -->
<?php include_once('includes/header.php'); ?>

<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-6">
                <div class="card"></div> <!-- .card -->
            </div><!--/.col-->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <strong> ADMINISTRATOR </strong> DASHBOARD
                    </div>
                    <div class="card-body card-block">
                        <div id="admin-dashboard" class="section">
                            <div class="top-metrics">
                                <div class="metric-box">
                                    <h3>Total Vehicle Parked</h3>
                                    <p id="total-vehicle-parked">0</p>
                                </div>
                                <div class="metric-box" id="total-parking-available-box">
                                    <h3>Total Parking Available</h3>
                                    <p id="total-parking-available">0</p>
                                </div>
                                <div class="metric-box" id="total-parking-booked-box">
                                    <h3>Total Parking Booked</h3>
                                    <p id="total-parking-booked">0</p>
                                </div>
                            </div>
                        
                            <div class="main-content">
                                <div class="chart-section">
                                    <canvas id="parkingChart"></canvas>
                                </div>
                                <div class="image-section">
                                    <img src="../admin/images/fkpark.png" alt="Parking Area Image" class="parking-area-image">
                                </div>
                            </div>
                            <div class="approval-section">
                                <h2>Approve Bookings</h2>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Booking ID</th>
                                            <th>Parking Area</th>
                                            <th>Slot Available</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="approveBookingsTableBody">
                                        <!-- Approve bookings details will be displayed here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div id="parkingAvailableModal" class="modal">
                            <div class="modal-content">
                                <span class="close" id="closeParkingAvailableModal">&times;</span>
                                <h2>Parking Available Details</h2>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Parking ID</th>
                                            <th>Location</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody id="parking-details">
                                        <!-- Parking details will be populated here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- Modal for Parking Booked Details -->
                        <div id="parkingBookedModal" class="modal">
                            <div class="modal-content">
                                <span class="close" id="closeParkingBookedModal">&times;</span>
                                <h2>Parking Booked Details</h2>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Booking ID</th>
                                            <th>Parking Area</th>
                                            <th>Slot Available</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>
                                        </tr>
                                    </thead>
                                    <tbody id="parking-booked-details">
                                        <!-- Parking booked details will be populated here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->
        <div class="clearfix"></div>
        <?php include_once('includes/footer.php'); ?>
    </div><!-- /#right-panel -->
    <!-- Right Panel -->
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>

  </body>
</html>
<?php } ?>
