<?php
include 'db.php';

$statusId = $_POST['statusId'];
$newStatus = $_POST['newStatus'];

// Preparing the SQL statement will prevent SQL injection.
if ($stmt = $conn->prepare('UPDATE parking SET status=? WHERE parking_id=?')) {
    // Bind the string parameters
    $stmt->bind_param('ss', $newStatus, $statusId);

    // Execute the statement
    $stmt->execute();

    // Check if the update was successful
    if ($stmt->affected_rows > 0) {
        echo "Status updated successfully";
    } else {
        echo "Error or no change in status: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
} else {
    // Something wrong with the query
    echo "Error preparing statement: " . $conn->error;
}

// Close connection
$conn->close();
?>
