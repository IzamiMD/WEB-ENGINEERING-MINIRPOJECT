function generateQRCode(data, elementId) {
    var qrcodeContainer = document.getElementById(elementId);
    qrcodeContainer.innerHTML = ""; 

    var qrCode = new QRCode(qrcodeContainer, data);

    setTimeout(function() {
        var img = qrcodeContainer.querySelector('img');
        if (img) {
            img.addEventListener('click', function() {
                var downloadLink = document.createElement('a');
                downloadLink.href = img.src;
                downloadLink.download = `QRCode_${elementId}.png`;
                downloadLink.click();
            });
        }
    }, 500);
}


function showModal(message) {
    var modal = document.getElementById('successModal');
    var messageElement = document.getElementById('successMessage');
    messageElement.textContent = message;
    modal.style.display = "block";
}

function closeModal() {
    var modal = document.getElementById('successModal');
    modal.style.display = "none";
}

function convertToUpperCase(form) {
    Array.from(form.elements).forEach(element => {
        if (element.tagName === 'INPUT' && element.type === 'text') {
            element.value = element.value.toUpperCase();
        }
    });
}

function handleFormSubmission(formId, url, successMessage) {
    document.getElementById(formId).addEventListener('submit', function(e) {
        e.preventDefault();

        convertToUpperCase(this);

        var formData = new FormData(this);
        var queryString = new URLSearchParams(formData).toString();

        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: queryString
        })
        .then(response => response.text())
        .then(data => {
            if (data.includes(successMessage)) {
                showModal(data);
                loadParkingSpaces();
            } else {
                showModal(`Error: ${data}`);
            }
            this.reset();
        })
        .catch(error => console.error('Error:', error));
    });
}

document.addEventListener('DOMContentLoaded', function() {
    handleFormSubmission('createParkingForm', 'create_parking.php', 'New record created successfully');
    handleFormSubmission('deleteParkingForm', 'delete_parking.php', 'Parking deleted successfully');
    handleFormSubmission('updateStatusForm', 'update_status.php', 'Status updated successfully');
    loadParkingSpaces();
});

function loadParkingSpaces() {
    fetch('fetch_parking_spaces.php')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('parkingTableBody');
            tableBody.innerHTML = '';
            data.forEach(space => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${space.parking_id}</td>
                    <td>${space.location}</td>
                    <td>${space.status}</td>
                    <td><div id="qrcode-${space.parking_id}"></div></td>
                `;
                tableBody.appendChild(row);
                generateQRCode(`http://localhost/ManageParking/parking_info.php?parking_id=${space.parking_id}`, `qrcode-${space.parking_id}`);
            });
        });
}

document.addEventListener('DOMContentLoaded', function() {
    loadParkingSpaces();
});

function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.style.display = 'none';
    });
    document.getElementById(sectionId).style.display = 'block';
}

document.querySelectorAll('button').forEach(button => {
    button.addEventListener('click', function() {
        const sectionId = this.getAttribute('onclick').replace('showSection(', '').replace(')', '').replace(/'/g, '');
        showSection(sectionId);
    });
});


document.addEventListener('DOMContentLoaded', function() {
    loadParkingSpaces();
});

showSection('manage-parking');
