<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsaid']==0)) {
  header('location:logout.php');
} else{
    if(isset($_GET['id'])) {
        $vehicleId = $_GET['id'];
        $query = "SELECT * FROM tblvehicle WHERE ID='$vehicleId'";
        $result = mysqli_query($con, $query);

        if(mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_array($result);
        } else {
            echo "<script>alert('Vehicle not found');</script>";
            echo "<script>window.location.href='view-vehicles.php'</script>";
        }
    } else {
        echo "<script>window.location.href='view-vehicles.php'</script>";
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VPMS - View Vehicle</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/p/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>
    <!-- Left Panel -->
    <?php include_once('includes/sidebar.php');?>
    <!-- Left Panel -->

    <!-- Right Panel -->
    <?php include_once('includes/header.php');?>
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">View Vehicle</strong>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="parkingnumber">Parking Number:</label>
                                <p><?php echo $row['ParkingNumber']; ?></p>
                            </div>
                            <div class="form-group">
                                <label for="vehiclecategory">Vehicle Category:</label>
                                <p><?php echo $row['VehicleCategory']; ?></p>
                            </div>
                            <div class="form-group">
                                <label for="registrationnumber">Registration Number:</label>
                                <p><?php echo $row['RegistrationNumber']; ?></p>
                            </div>
                            <div class="form-group">
                                <label for="ownername">Owner Name:</label>
                                <p><?php echo $row['OwnerName']; ?></p>
                            </div>
                            <div class="form-group">
                                <label for="ownercontactnumber">Owner Contact Number:</label>
                                <p><?php echo $row['OwnerContactNumber']; ?></p>
                            </div>
                            <div class="form-group">
                                <label for="intime">In Time:</label>
                                <p><?php echo $row['InTime']; ?></p>
                            </div>
                            <div class="form-group">
                                <label for="outtime">Out Time:</label>
                                <p><?php echo $row['OutTime']; ?></p>
                            </div>
                            <div class="form-group">
                                <label for="parkingcharge">Parking Charge:</label>
                                <p><?php echo $row['ParkingCharge']; ?></p>
                            </div>
                            <div class="form-group">
                                <label for="remark">Remark:</label>
                                <p><?php echo $row['Remark']; ?></p>
                            </div>
                            <div class="form-group">
                                <label for="status">Status:</label>
                                <p><?php echo $row['Status']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Right Panel -->
    <?php include_once('includes/footer.php');?>
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>

<?php } ?>
