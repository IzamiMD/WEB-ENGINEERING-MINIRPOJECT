<?php
include('includes/dbconnection.php');

$query_regusers = "SELECT COUNT(*) as total FROM tblregusers";
$result_regusers = mysqli_query($con, $query_regusers);
$row_regusers = mysqli_fetch_assoc($result_regusers);
$regusers_total = $row_regusers['total'];

$query_admins = "SELECT COUNT(*) as total FROM tbladmin";
$result_admins = mysqli_query($con, $query_admins);
$row_admins = mysqli_fetch_assoc($result_admins);
$admins_total = $row_admins['total'];

$data = array('regusers' => $regusers_total, 'admins' => $admins_total);
echo json_encode($data);
?>
