<?php
include('../includes/dbconnection.php');

$query = "SELECT Booking_ID, parkingArea, slotAvailable, StartTime, EndTime FROM parkingbooking WHERE Confirmed = 2";
$result = mysqli_query($con, $query);

$response = [];
while ($row = mysqli_fetch_assoc($result)) {
    $response[] = $row;
}

// Output the response in JSON format
echo json_encode($response);

mysqli_close($con);
?>
