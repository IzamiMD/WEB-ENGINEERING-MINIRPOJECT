<?php
include('../includes/dbconnection.php');

// Check if the parkingArea parameter is set
$parkingArea = isset($_GET['parkingArea']) ? $_GET['parkingArea'] : 'all';

$response = [];

// Query to get the total number of vehicles parked (where confirmed = 1)
$query = "SELECT COUNT(*) as totalVehicleParked FROM parkingbooking WHERE Confirmed = 1";
if ($parkingArea !== 'all') {
    $query .= " AND parkingArea = '$parkingArea'";
}
$result = mysqli_query($con, $query);
$row = mysqli_fetch_assoc($result);
$response['totalVehicleParked'] = $row['totalVehicleParked'];

// Query to get the total number of parking booked (all statuses)
$query = "SELECT COUNT(*) as totalParkingBooked FROM parkingbooking";
if ($parkingArea !== 'all') {
    $query .= " WHERE parkingArea = '$parkingArea'";
}
$result = mysqli_query($con, $query);
$row = mysqli_fetch_assoc($result);
$response['totalParkingBooked'] = $row['totalParkingBooked'];

// Query to get the total number of available parking slots
$query = "SELECT COUNT(*) as totalParkingAvailable FROM parking WHERE status = 'available'";
if ($parkingArea !== 'all') {
    $query .= " AND location = '$parkingArea'";
}
$result = mysqli_query($con, $query);
$row = mysqli_fetch_assoc($result);
$response['totalParkingAvailable'] = $row['totalParkingAvailable'];

// Output the response in JSON format
echo json_encode($response);

mysqli_close($con);
?>
