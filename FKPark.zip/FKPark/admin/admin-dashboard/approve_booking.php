<?php
include('../includes/dbconnection.php');

if (isset($_POST['bookingId'])) {
    $bookingId = $_POST['bookingId'];

    $query = "UPDATE parkingbooking SET Confirmed = 1 WHERE Booking_ID = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("i", $bookingId);

    if ($stmt->execute()) {
        echo "Booking approved successfully.";
    } else {
        echo "Failed to approve booking.";
    }

    $stmt->close();
    $con->close();
} else {
    echo "No booking ID provided.";
}
?>
