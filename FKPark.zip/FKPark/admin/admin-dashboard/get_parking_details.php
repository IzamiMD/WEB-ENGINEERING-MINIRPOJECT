<?php
include('../includes/dbconnection.php');

// Check if the parkingArea parameter is set
$parkingArea = isset($_GET['parkingArea']) ? $_GET['parkingArea'] : 'all';

$query = "SELECT Booking_ID, parkingArea, slotAvailable, StartTime, EndTime FROM parkingbooking WHERE Confirmed = 0";
if ($parkingArea !== 'all') {
    $query .= " AND parkingArea = '$parkingArea'";
}
$result = mysqli_query($con, $query);

$response = [];
while ($row = mysqli_fetch_assoc($result)) {
    $response[] = $row;
}

// Output the response in JSON format
echo json_encode($response);

mysqli_close($con);
?>
