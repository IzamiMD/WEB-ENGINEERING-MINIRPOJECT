<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="device-width, initial-scale=1.0">
    <title>Preview</title>
    <link href="css/form.css" rel="stylesheet" type="text/css">
</head>

<body>
<section class="header">
<div class="information">
    <div class="heading2">Preview Only</div>
    <form>
      <div class="user-details">
        <div class="input-box">
          <span class="details">Summon ID</span>
            <div class="box" id="summonId">Summon ID</div>
        </div>        
        <div class="input-box">
          <span class="details">User ID</span>
            <div class="box" id="userId">User ID</div>
        </div>
        <div class="input-box">
          <span class="details">Vehicle ID</span>
            <div class="box" id="vehicleId">Vehicle ID</div>
        </div>
        <div class="input-box">
          <span class="details">Demerit Point</span>
          <div class="box" id="demeritPoint">Demerit Point</div>
        </div>
        <div class="input-box">
          <span class="details">Car Type</span>
          <div class="box" id="carType">Type</div>
        </div>
        <div class="input-box">
          <span class="details">Enforcement Type</span>
          <div class="box" id="enforcementType">Type</div>
        </div>
      </div>
      <div class="thanks">
          <span>THANK YOU</span>
          <br>
          <button class="print" type="button" onclick="window.print()">Print</button>
      </div>
          
    </form>
</div>
</section>
<script src="js/preview.js"></script>
</body>
</html>
