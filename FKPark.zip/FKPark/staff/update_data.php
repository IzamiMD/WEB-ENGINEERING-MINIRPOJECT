<?php
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "vpmsdb";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $summonId = $_POST['summonId'];
    $userId = $_POST['userId'];
    $vehicleId = $_POST['vehicleId'];
    $demeritPoint = $_POST['demeritPoint'];
    $carType = $_POST['carType'];


    $stmt = $conn->prepare("UPDATE summon_information SET userId = ?, vehicleId = ?, demeritPoint = ?, carType = ? WHERE summonId = ?");
    $stmt->bind_param("ssiss", $userId, $vehicleId, $demeritPoint, $carType, $summonId);

    if ($stmt->execute() === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();

// Redirect back
header("Location: SummonTable.php");
exit();
?>
