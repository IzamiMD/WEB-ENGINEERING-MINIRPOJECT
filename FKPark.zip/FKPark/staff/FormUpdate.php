<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="device-width, initial-scale=1.0">
    <title>Update Summon Information</title>
    <link href="css/form.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/table.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <button onclick="goBack()" class="go-back-btn">Go Back</button>
            <section class="header">
                <div class="information">
                    <div class="heading">Update Information</div>
                    <form id="summonForm" action="update_data.php" method="POST">
                        <div class="user-details">
                            <div class="input-box">
                                <span class="details">Summon ID</span>
                                <input type="text" id="summonId" name="summonId" readonly>
                            </div>
                            <div class="input-box">
                                <span class="details">User ID</span>
                                <input type="text" id="userId" name="userId" required>
                            </div>
                            <div class="input-box">
                                <span class="details">Vehicle ID</span>
                                <input type="text" id="vehicleId" name="vehicleId" required>
                            </div>
                            <div class="inputfield">
                                <span class="details">Car Type</span>
                                <select id="carType" name="carType" required>
                                    <option value="" disabled="disabled" selected="selected">---</option>
                                    <option value="Hatchback">Hatchback</option>
                                    <option value="Sedan">Sedan</option>
                                    <option value="SUV">SUV</option>
                                </select>
                            </div>
                            <div class="input-box">
                                <span class="details">Demerit Point</span>
                                <input type="number" id="demeritPoint" name="demeritPoint" required oninput="updateEnforcementType()">
                            </div>
                            <div class="input-box">
                                <span class="details">Enforcement Type</span>
                                <div class="box" id="enforcementType">Type</div>
                            </div>
                        </div>
                        <div class="buttonRow">
                            <input type="submit" class="btnUpdate" value="Update">
                        </div>
                    </form>
                </div>
            </section>
        
    <script src="js/fullscreen.js"></script>
    <script src="js/formUpdateHandler.js"></script>
    <script>
        function goBack() {
            window.history.back();
        }
    </script>
</body>
</html>
