<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('../includes/dbconnection.php');

header('Content-Type: application/json');

if (strlen($_SESSION['vpmsaid']) == 0) {
    echo json_encode(['success' => false, 'error' => 'User not logged in.']);
    exit;
} else {
    $staffid = $_SESSION['vpmsaid'];
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : 'staff';

    $parkingArea = $_POST['parkingArea'];
    $slotAvailable = $_POST['slotAvailable'];
    $startTime = $_POST['startTime'];
    $endTime = $_POST['endTime'];
    $timeSlot = $_POST['time_slot']; // Make sure time_slot is fetched from POST data

    // Generate a random 5-digit booking ID
    $bookingId = rand(10000, 99999);

    // Determine parking ID based on slotAvailable
    $parkingId = 0;
    switch ($slotAvailable) {
        case 'slot1':
            $parkingId = 1;
            break;
        case 'slot2':
            $parkingId = 2;
            break;
        case 'slot3':
            $parkingId = 3;
            break;
        case 'slot4':
            $parkingId = 4;
            break;
        case 'slot5':
            $parkingId = 5;
            break;
        case 'slot6':
            $parkingId = 6;
            break;
        case 'slot7':
            $parkingId = 7;
            break;
        case 'slot8':
            $parkingId = 8;
            break;
        case 'slot9':
            $parkingId = 9;
            break;
        case 'slot10':
            $parkingId = 10;
            break;
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid slot available.']);
            exit;
    }

    if (empty($parkingArea) || empty($slotAvailable) || empty($startTime) || empty($endTime) || empty($timeSlot)) {
        echo json_encode(['success' => false, 'error' => 'Missing required fields']);
        exit;
    }

    $query = $con->prepare("INSERT INTO parkingbooking (Booking_ID, staff_id, parkingArea, slotAvailable, StartTime, EndTime, time_slot, parking_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $query->bind_param("iisssssi", $bookingId, $staffid, $parkingArea, $slotAvailable, $startTime, $endTime, $timeSlot, $parkingId);

    try {
        $query->execute();
        echo json_encode(['success' => true, 'bookingId' => $bookingId]);
    } catch (mysqli_sql_exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}
?>
