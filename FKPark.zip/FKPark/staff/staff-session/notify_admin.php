<?php
session_start();
include('../includes/dbconnection.php');

header('Content-Type: application/json');

if (strlen($_SESSION['vpmsaid']) == 0) {
    echo json_encode(['success' => false, 'error' => 'User not logged in.']);
    exit;
}

if (isset($_POST['bookingId'])) {
    $bookingId = intval($_POST['bookingId']);

    // Update the booking status to confirmed (2)
    $query = $con->prepare("UPDATE parkingbooking SET Confirmed = 2 WHERE Booking_ID = ?");
    if ($query) {
        $query->bind_param("i", $bookingId);
        if ($query->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to update booking.']);
        }
        $query->close();
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to prepare query.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No booking ID provided.']);
}

$con->close();
?>
