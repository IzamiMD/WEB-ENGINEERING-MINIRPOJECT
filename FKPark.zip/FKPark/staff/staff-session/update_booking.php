<?php
session_start();
include('../includes/dbconnection.php');

if (strlen($_SESSION['vpmsaid']) == 0) {
    header('location:logout.php');
} else {
    if (isset($_POST['bookingId']) && isset($_POST['parkingArea']) && isset($_POST['slotAvailable']) && isset($_POST['startTime']) && isset($_POST['endTime'])) {
        $bookingId = intval($_POST['bookingId']);
        $parkingArea = $_POST['parkingArea'];
        $slotAvailable = $_POST['slotAvailable'];
        $startTime = $_POST['startTime'];
        $endTime = $_POST['endTime'];

        $query = $con->prepare("UPDATE parkingbooking SET parkingArea=?, slotAvailable=?, StartTime=?, EndTime=? WHERE Booking_ID=?");
        $query->bind_param("ssssi", $parkingArea, $slotAvailable, $startTime, $endTime, $bookingId);
        if ($query->execute()) {
            echo "Booking updated successfully";
        } else {
            echo "Failed to update booking: " . $query->error;
        }
        $query->close();
    } else {
        echo "Invalid request";
    }
    $con->close();
}
?>
