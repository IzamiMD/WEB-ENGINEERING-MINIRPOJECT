<?php
session_start();
include('../includes/dbconnection.php');

header('Content-Type: application/json');

if (strlen($_SESSION['vpmsaid']) == 0) {
    echo json_encode(['success' => false, 'error' => 'User not logged in.']);
    exit;
} else {
    $staffid = $_SESSION['vpmsaid'];

    $query = $con->prepare("SELECT Booking_ID, parkingArea, slotAvailable, StartTime, EndTime, Confirmed FROM parkingbooking WHERE staff_id = ?");
    $query->bind_param("i", $staffid);
    $query->execute();
    $result = $query->get_result();

    $bookings = [];
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
    echo json_encode($bookings);
}
?>
