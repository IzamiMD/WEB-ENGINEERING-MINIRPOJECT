<?php
session_start();
include('../includes/dbconnection.php');

header('Content-Type: application/json');

if (strlen($_SESSION['vpmsaid']) == 0) {
    echo json_encode(['success' => false, 'error' => 'User not logged in.']);
    exit;
}

if (isset($_GET['bookingId'])) {
    $bookingId = intval($_GET['bookingId']); // Ensure bookingId is an integer

    $query = $con->prepare("SELECT * FROM parkingbooking WHERE Booking_ID = ?");
    if ($query) {
        $query->bind_param("i", $bookingId);
        $query->execute();
        $result = $query->get_result();

        if ($result->num_rows > 0) {
            echo json_encode($result->fetch_assoc());
        } else {
            echo json_encode(['success' => false, 'error' => 'Booking not found.']);
        }

        $query->close();
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to prepare query.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No booking ID provided.']);
}

$con->close();
?>
