<?php
session_start();
include('../includes/dbconnection.php');

header('Content-Type: application/json');

if (strlen($_SESSION['vpmsaid']) == 0) {
    echo json_encode(['success' => false, 'error' => 'User not logged in.']);
    exit;
} else {
    $bookingId = $_POST['bookingId'];

    $query = $con->prepare("UPDATE parkingbooking SET Confirmed = 2 WHERE Booking_ID = ?");
    $query->bind_param("i", $bookingId);

    try {
        $query->execute();
        echo json_encode(['success' => true]);
    } catch (mysqli_sql_exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}
?>
