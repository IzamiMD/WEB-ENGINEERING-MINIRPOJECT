 <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"><i class="menu-icon fa fa-laptop"></i>User Dashboard </a>
                    </li>
                    <li class="active">
                        <a href="staffdashboard.php"><i class="menu-icon fa fa-laptop"></i>Staff Dashboard </a>
                    </li>
                   
                   
                    
                    <li>
                        <a href="add-vehicle.php"> <i class="menu-icon ti-email"></i>Register Vehicle </a>
                    </li>
                    
                    <li class="menu-item-has-children dropdown">
                        <ul class="sub-menu children dropdown-menu">
                            
                           
                        </li>

                        </ul>
                    </li>
                    

                  
                    <li>
                        <a href="view-vehicles.php"> <i class="menu-icon ti-user"></i>Registered Vehicles </a>
                    </li>
                    <li>
                        <a href="staff-booking.php"> <i class="menu-icon ti-user"></i>Book Parking </a>
                    </li>
                    <li>
                        <a href="form.php"> <i class="menu-icon ti-user"></i>Record Traffic Violation </a>
                    </li>
                    <li>
                        <a href="SummonTable.php"> <i class="menu-icon ti-user"></i>Summon Information</a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>