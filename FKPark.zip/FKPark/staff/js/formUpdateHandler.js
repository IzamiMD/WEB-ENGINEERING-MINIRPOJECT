document.addEventListener('DOMContentLoaded', function() {
    // Function to fetch data based on summonId query parameter
    function fetchData() {
        const urlParams = new URLSearchParams(window.location.search);
        const summonId = urlParams.get('summonId');
        if (summonId) {
            fetch(`fetch_single_data.php?summonId=${summonId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        alert(data.error);
                    } else {
                        document.getElementById('summonId').value = data.summonId;
                        document.getElementById('userId').value = data.userId;
                        document.getElementById('vehicleId').value = data.vehicleId;
                        document.getElementById('demeritPoint').value = data.demeritPoint;
                        document.getElementById('carType').value = data.carType;
                        updateEnforcementType(); // Update enforcement type on page load
                    }
                })
                .catch(error => console.error('Error fetching data:', error));
        }
    }

    // Function to update enforcement type based on demerit points
    function updateEnforcementType() {
        const demeritPoint = document.getElementById('demeritPoint').value;
        let enforcementType = 'Type';

        if (demeritPoint < 20) {
            enforcementType = 'Warning given';
        } else if (demeritPoint < 50) {
            enforcementType = 'Revoke of in campus vehicle permission for 1 semester';
        } else if (demeritPoint < 80) {
            enforcementType = 'Revoke of in campus vehicle permission for 2 semesters';
        } else if (demeritPoint >= 80) {
            enforcementType = 'Revoke of in campus vehicle permission for the entire study duration';
        }

        document.getElementById('enforcementType').innerText = enforcementType;
    }

    // Event listener for demerit points input field
    document.getElementById('demeritPoint').addEventListener('input', updateEnforcementType);

    // Fetch data when the page loads
    fetchData();
});
