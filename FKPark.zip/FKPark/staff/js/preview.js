document.addEventListener('DOMContentLoaded', function() {
    // Function to determine enforcement type based on demerit points
    function getEnforcementType(demeritPoints) {
        if (demeritPoints < 20) {
            return "Warning given";
        } else if (demeritPoints < 50) {
            return "Revoke of in campus vehicle permission for 1 semester";
        } else if (demeritPoints < 80) {
            return "Revoke of in campus vehicle permission for 2 semesters";
        } else {
            return "Revoke of in campus vehicle permission for the entire study duration";
        }
    }

    // Function to fetch data based on summonId query parameter
    function fetchData() {
        const urlParams = new URLSearchParams(window.location.search);
        const summonId = urlParams.get('summonId');
        if (summonId) {
            fetch(`fetch_single_data.php?summonId=${summonId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        alert(data.error);
                    } else {
                        document.getElementById('summonId').innerText = data.summonId;
                        document.getElementById('userId').innerText = data.userId;
                        document.getElementById('vehicleId').innerText = data.vehicleId;
                        document.getElementById('demeritPoint').innerText = data.demeritPoint;
                        document.getElementById('carType').innerText = data.carType;

                        // Calculate and set enforcement type
                        const enforcementType = getEnforcementType(data.demeritPoint);
                        document.getElementById('enforcementType').innerText = enforcementType;
                    }
                })
                .catch(error => console.error('Error fetching data:', error));
        }
    }

    // Fetch data when the page loads
    fetchData();
});
