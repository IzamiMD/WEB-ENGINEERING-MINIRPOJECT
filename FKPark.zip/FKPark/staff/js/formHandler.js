let summonCounter = 1;

// Function to fetch existing Summon IDs
function fetchExistingSummonIds() {
    return fetch('php/fetch_data.php')
        .then(response => response.json())
        .then(data => data.map(row => row.summonId))
        .catch(error => {
            console.error('Error fetching existing Summon IDs:', error);
            return [];
        });
}

// Function to generate a unique Summon ID
async function generateSummonId() {
    const existingSummonIds = await fetchExistingSummonIds();
    let newSummonId;
    
    do {
        newSummonId = 'S' + String(summonCounter).padStart(3, '0');
        summonCounter++;
    } while (existingSummonIds.includes(newSummonId));

    document.getElementById('summonIdBox').innerText = newSummonId;
    document.getElementById('summonId').value = newSummonId;
}

function updateEnforcementType() {
    const demeritPoint = document.getElementById('demeritPoint').value;
    let enforcementType = 'Type';

    if (demeritPoint < 20) {
        enforcementType = 'Warning given';
    } else if (demeritPoint < 50) {
        enforcementType = 'Revoke of in campus vehicle permission for 1 semester';
    } else if (demeritPoint < 80) {
        enforcementType = 'Revoke of in campus vehicle permission for 2 semesters';
    } else if (demeritPoint >= 80) {
        enforcementType = 'Revoke of in campus vehicle permission for the entire study duration';
    }

    document.getElementById('enforcementType').innerText = enforcementType;
}

function submitForm() {
    const form = document.getElementById('summonForm');
    if (form.checkValidity()) {
        // The form will be submitted via POST method defined in the form action
        // Form submission will be handled by the browser's default behavior
    } else {
        alert('Please fill in all required fields.');
    }
}

function cancelForm() {
    if (confirm('Are you sure you want to cancel?')) {
        document.getElementById('summonForm').reset();
        generateSummonId(); // Regenerate Summon ID after reset
        document.getElementById('enforcementType').innerText = 'Type'; // Reset enforcement type
    }
}

// Fullscreen functionality
var fullscreen = document.getElementById("fullscreen");
var el = document.documentElement;
fullscreen.addEventListener("click", () => {
    if (el.requestFullscreen) {
        el.requestFullscreen();
    }
});

// Function to show alerts based on query parameters
function showAlert() {
    const urlParams = new URLSearchParams(window.location.search);
    const status = urlParams.get('status');

    if (status === 'success') {
        alert('Record added successfully!');
        // Remove the query parameters from the URL
        history.replaceState(null, "", window.location.pathname);
    } else if (status === 'error') {
        alert('There was an error adding the record.');
        // Remove the query parameters from the URL
        history.replaceState(null, "", window.location.pathname);
    }
}

// Call showAlert function when the page loads
window.onload = function() {
    showAlert();
    generateSummonId(); // Generate Summon ID when the page loads
};
