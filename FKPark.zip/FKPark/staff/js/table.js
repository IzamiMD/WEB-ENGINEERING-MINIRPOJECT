document.addEventListener('DOMContentLoaded', function() {
    // Function to fetch data from the server
    function fetchData() {
        fetch('php/fetch_data.php')
            .then(response => response.json())
            .then(data => {
                const tbody = document.getElementById('summonData');
                tbody.innerHTML = ''; // Clear existing data
                data.forEach(row => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td data-table="Summon ID">${row.summonId}</td>
                        <td data-table="User ID">${row.userId}</td>
                        <td data-table="Vehicle ID">${row.vehicleId}</td>
                        <td data-table="Demerit Point">${row.demeritPoint}</td>
                        <td data-table="Type">${row.carType}</td>
                        <td><input type="button" class="status update" value="Update"></td>
                        <td><input type="button" class="status delete" value="Delete"></td>
                        <td><input type="button" class="status download" value="Download"></td>
                        <td><input type="button" class="status qr" value="QR"></td>
                    `;
                    tbody.appendChild(tr);
                });
                attachButtonHandlers();
            })
            .catch(error => console.error('Error fetching data:', error));
    }

    // Function to attach button handlers
    function attachButtonHandlers() {
        document.querySelectorAll('.status.update').forEach(button => {
            button.addEventListener('click', function() {
                const summonId = this.closest('tr').querySelector('td[data-table="Summon ID"]').innerText.trim();
                handleUpdate(summonId);
            });
        });

        document.querySelectorAll('.status.delete').forEach(button => {
            button.addEventListener('click', function() {
                const summonId = this.closest('tr').querySelector('td[data-table="Summon ID"]').innerText.trim();
                handleDelete(summonId);
            });
        });

        document.querySelectorAll('.status.download').forEach(button => {
            button.addEventListener('click', function() {
                const summonId = this.closest('tr').querySelector('td[data-table="Summon ID"]').innerText.trim();
                handleDownload(summonId);
            });
        });

        document.querySelectorAll('.status.qr').forEach(button => {
            button.addEventListener('click', function() {
                const row = this.closest('tr');
                const summonId = row.querySelector('td[data-table="Summon ID"]').innerText.trim();
                const userId = row.querySelector('td[data-table="User ID"]').innerText.trim();
                const vehicleId = row.querySelector('td[data-table="Vehicle ID"]').innerText.trim();
                const demeritPoint = row.querySelector('td[data-table="Demerit Point"]').innerText.trim();
                const carType = row.querySelector('td[data-table="Type"]').innerText.trim();
                handleQR(summonId, userId, vehicleId, demeritPoint, carType);
            });
        });
    }

    // Function to handle the update action
    function handleUpdate(summonId) {
        // Redirect to the update form with the summonId as a query parameter
        window.location.href = `FormUpdate.php?summonId=${summonId}`;
    }

    // Function to handle the delete action
    function handleDelete(summonId) {
        if (confirm(`Are you sure you want to delete record Summon ID: ${summonId}?`)) {
            // Send delete request to the server
            fetch('php/delete_data.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `summonId=${encodeURIComponent(summonId)}`
            })
            .then(response => response.text())
            .then(message => {
                alert(message);
                fetchData(); // Refresh the data
            })
            .catch(error => console.error('Error deleting data:', error));
        }
    }

    // Function to handle the download action
    function handleDownload(summonId) {
        // Open the preview page in a new tab with the summonId as a query parameter
        window.open(`preview.php?summonId=${summonId}`, '_blank');
    }

    // Function to handle the QR action
    function handleQR(summonId, userId, vehicleId, demeritPoint, carType) {
        // Generate QR code with all data
        const qrData = `
            Summon ID: ${summonId}
            User ID: ${userId}
            Vehicle ID: ${vehicleId}
            Demerit Point: ${demeritPoint}
            Type Car: ${carType}
        `;

        const modal = document.getElementById('qrModal');
        const qrcodeContainer = document.getElementById('qrcode');
        qrcodeContainer.innerHTML = ''; // Clear any existing QR code
        new QRCode(qrcodeContainer, {
            text: qrData.trim(),
            width: 128,
            height: 128
        });
        modal.style.display = 'block';
    }

    // Function to handle modal close
    function closeModal() {
        const modal = document.getElementById('qrModal');
        modal.style.display = 'none';
    }

    // Search function
    function searchTable() {
        const searchInput = document.querySelector('.input-group input');
        const tableRows = document.querySelectorAll('#summonData tr');

        searchInput.addEventListener('input', function() {
            const searchTerm = searchInput.value.toLowerCase();
            tableRows.forEach(row => {
                const rowData = row.textContent.toLowerCase();
                row.style.display = rowData.includes(searchTerm) ? '' : 'none';
            });
        });
    }

    // Sort function
    function sortTable() {
        const tableHeadings = document.querySelectorAll('thead th');
        const tableRows = document.querySelectorAll('#summonData tr');

        tableHeadings.forEach((header, index) => {
            header.addEventListener('click', function() {
                const isAscending = header.classList.toggle('asc');
                const direction = isAscending ? 1 : -1;
                const rowsArray = Array.from(tableRows);

                rowsArray.sort((a, b) => {
                    const cellA = a.querySelectorAll('td')[index].textContent.toLowerCase();
                    const cellB = b.querySelectorAll('td')[index].textContent.toLowerCase();
                    return cellA > cellB ? direction : cellA < cellB ? -direction : 0;
                });

                rowsArray.forEach(row => document.querySelector('#summonData').appendChild(row));
            });
        });
    }

    // Fetch data when the page loads
    fetchData();

    // Initialize search and sort functions
    searchTable();
    sortTable();

    // Handle modal close
    const modal = document.getElementById('qrModal');
    const span = document.getElementsByClassName('close')[0];
    span.onclick = closeModal;
    window.onclick = function(event) {
        if (event.target == modal) {
            closeModal();
        }
    }
});
