<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="device-width, initial-scale=1.0">
    <title>Summon Information</title>
    <link href="css/form.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="../css/table.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <button onclick="goBack()" class="go-back-btn">Go Back</button>
            <section class="header">
                <div class="information">
                    <div class="heading">Please fill in the blank:</div>
                    <form id="summonForm" action="submit_form.php" method="POST">
                        <div class="user-details">
                            <div class="input-box">
                                <span class="details">Summon ID</span>
                                <div class="box" id="summonIdBox">Summon ID</div>
                                <input type="hidden" id="summonId" name="summonId">
                            </div>
                            <div class="input-box">
                                <span class="details">User ID</span>
                                <input type="text" placeholder="" id="userId" name="userId" required>
                            </div>
                            <div class="input-box">
                                <span class="details">Vehicle ID</span>
                                <input type="text" placeholder="" id="vehicleId" name="vehicleId" required>
                            </div>
                            <div class="inputfield">
                                <span class="details">Car Type</span>
                                <select id="carType" name="carType" required>
                                    <option value="" disabled="disabled" selected="selected">---</option>
                                    <option value="Hatchback">Hatchback</option>
                                    <option value="Sedan">Sedan</option>
                                    <option value="SUV">SUV</option>
                                </select>
                            </div>
                            <div class="input-box">
                                <span class="details">Demerit Point</span>
                                <input type="number" placeholder="" id="demeritPoint" name="demeritPoint" required oninput="updateEnforcementType()">
                            </div>
                            <div class="input-box">
                              <span class="details">Enforcement Type</span>
                              <div class="box" id="enforcementType">Type</div>
                            </div>
                        </div>
                        <div class="buttonRow">
                            <input type="submit" class="btnAdd" value="Add">
                            <input type="button" class="btnCancel" value="Cancel" onclick="cancelForm()">
                            <input type="reset" class="btnReset" value="Reset">
                        </div>
                    </form>
                </div>
            </section>
    
                <div id="fullscreen" class="nav-icon" onclick="toggleFullscreen()">
                    <a href="javascript:void(0)"><i class='bx bx-fullscreen'></i></a>
                    <span>Fullscreen</span>
                </div>
        
    <script src="js/fullscreen.js"></script>
    <script src="js/formHandler.js"></script>
    <script>
        function goBack() {
            window.history.back();
        }
    </script>
</body>
</html>
