<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['vpmsaid'] == 0)) {
  header('location:logout.php');
} else {
  // Fetch data counts from the database
  $regusers_query = mysqli_query($con, "SELECT COUNT(*) AS count FROM tblregusers");
  $admin_query = mysqli_query($con, "SELECT COUNT(*) AS count FROM tbladmin");
  $staff_query = mysqli_query($con, "SELECT COUNT(*) AS count FROM tblstaff");

  $regusers_count = mysqli_fetch_assoc($regusers_query)['count'];
  $admin_count = mysqli_fetch_assoc($admin_query)['count'];
  $staff_count = mysqli_fetch_assoc($staff_query)['count'];
?>

<!doctype html>
<html class="no-js" lang="">
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <!-- Include other styles and scripts here -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include_once('includes/sidebar.php');?>
    <?php include_once('includes/header.php');?>

    <div class="breadcrumbs">
        <!-- Breadcrumb content here -->
    </div>

    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>User Dashboard</strong>
                        </div>
                        <div class="card-body card-block">
                        <div style="width: 500px; height: 500px;">
                            <canvas id="myPieChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include_once('includes/footer.php');?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var ctx = document.getElementById('myPieChart').getContext('2d');
            var myPieChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ['Students', 'Admins', 'Staff'],
                    datasets: [{
                        data: [
                            <?php echo $regusers_count; ?>,
                            <?php echo $admin_count; ?>,
                            <?php echo $staff_count; ?>
                        ],
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.2)',
                            'rgba(54, 162, 235, 0.2)',
                            'rgba(255, 206, 86, 0.2)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Distribution of Users, Admins, and Staff'
                        }
                    }
                }
            });
        });
    </script>



</body>
</html>
<?php } ?>