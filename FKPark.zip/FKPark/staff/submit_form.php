<?php
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "vpmsdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $summonId = $_POST['summonId'];
    $userId = $_POST['userId'];
    $vehicleId = $_POST['vehicleId'];
    $demeritPoint = $_POST['demeritPoint'];
    $carType = $_POST['carType'];

    $sql = "INSERT INTO summon_information (summonId, userId, vehicleId, demeritPoint, carType) 
            VALUES ('$summonId', '$userId', '$vehicleId', '$demeritPoint', '$carType')";

    if ($conn->query($sql) === TRUE) {
        header("Location: Form.php?status=success");
        exit();
    } else {
        header("Location: Form.php?status=error");
        exit();
    }

    $conn->close();
}
?>
