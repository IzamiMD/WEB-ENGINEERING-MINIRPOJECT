<?php
session_start();
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsuid']==0)) {
    header('location:logout.php');
} else {
    $vid = intval($_GET['vid']);
    $query = mysqli_query($con, "UPDATE tblvehicle SET ApprovalStatus='Rejected' WHERE ID='$vid'");
    if ($query) {
        echo "<script>alert('Vehicle Rejected');</script>";
        echo "<script>window.location.href='view-all-vehicle.php'</script>";
    } else {
        echo "<script>alert('Something went wrong. Please try again.');</script>";
    }
}
?>