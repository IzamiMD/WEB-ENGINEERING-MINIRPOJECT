<?php
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "vpmsdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the summonId is set in the request
if (isset($_GET['summonId'])) {
    $summonId = $_GET['summonId'];

    // Prepare the SQL statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM summon_information WHERE summonId = ?");
    $stmt->bind_param("s", $summonId);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $data = $result->fetch_assoc();
            echo json_encode($data);
        } else {
            echo json_encode(array("error" => "No record found"));
        }
    } else {
        echo json_encode(array("error" => "Error executing query"));
    }

    $stmt->close();
}

$conn->close();
?>
