<?php
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "vpmsdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT COUNT(*) as total FROM summon_information"; // Make sure this table name is correct
$result = $conn->query($sql);

if ($result === FALSE) {
    echo json_encode(['error' => $conn->error]);
} else {
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode(['total' => $row['total']]);
    } else {
        echo json_encode(['total' => 0]);
    }
}

$conn->close();
?>
