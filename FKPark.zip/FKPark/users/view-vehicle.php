<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
include('phpqrcode/qrlib.php');

if (strlen($_SESSION['vpmsuid']==0)) {
  header('location:logout.php');
} else {
?>

<!doctype html>
<html class="no-js" lang="">
<head>
    <title>VPMS - View Vehicle Parking Details</title>
    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="../admin/assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../admin/assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <!-- Include QRCode library -->
    <script src="../assets/qrcodejs-master/qrcode.min.js"></script>
    <!-- Include jQuery library -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <!-- Left Panel -->
    <?php include_once('includes/sidebar.php');?>

    <!-- Left Panel -->
    <!-- Right Panel -->
    <?php include_once('includes/header.php');?>

    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Dashboard</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard.php">Dashboard</a></li>
                                <li><a href="view-vehicle.php">View Vehicle Parking Details</a></li>
                                <li class="active">View Vehicle Parking Details</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">View Vehicles</strong>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>S.NO</th>
                                        <th>Parking Number</th>
                                        <th>Owner Name</th>
                                        <th>Vehicle Reg Number</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <?php
                                $uid = $_SESSION['vpmsuid'];
                                $ret = mysqli_query($con, "SELECT tblregusers.FirstName, tblregusers.LastName, tblvehicle.ParkingNumber, tblvehicle.RegistrationNumber, tblvehicle.OwnerName, tblvehicle.ID as vehid, tblvehicle.ApprovalStatus 
                                                           FROM tblvehicle 
                                                           JOIN tblregusers ON tblregusers.MobileNumber = tblvehicle.OwnerContactNumber 
                                                           WHERE tblregusers.ID = '$uid'");
                                $cnt = 1;
                                while ($row = mysqli_fetch_array($ret)) {
                                ?>
                                <tr>
                                    <td><?php echo $cnt;?></td>
                                    <td><?php echo $row['ParkingNumber'];?></td>
                                    <td><?php echo $row['OwnerName'];?></td>
                                    <td><?php echo $row['RegistrationNumber'];?></td>
                                    <td>
                                        <a href="view--detail.php?viewid=<?php echo $row['vehid'];?>" class="btn btn-primary">View</a>
                                        <?php if($row['ApprovalStatus'] == 'Approved') { ?>
                                        <a href="javascript:void(0);" onclick="generateQRCode(<?php echo $row['vehid']; ?>);" class="btn btn-warning">Generate QR</a>
                                        <?php } ?>
                                        <a href="edit-vehicle.php?vid=<?php echo $row['vehid'];?>" class="btn btn-info">Edit</a>
                                        <a href="delete-vehicle.php?vid=<?php echo $row['vehid'];?>" class="btn btn-danger">Delete</a>
                                    </td>
                                </tr>
                                <?php 
                                $cnt = $cnt + 1;
                                } ?>
                            </table>
                            <div id="qrcode" style="display: none;"></div>
                            <button id="downloadQR" style="display: none;">Download QR Code</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->

<div class="clearfix"></div>
<?php include_once('includes/footer.php');?>
</div><!-- /#right-panel -->
<!-- Right Panel -->

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="../admin/assets/js/main.js"></script>
<script>
    function generateQRCode(vehicleId) {
        console.log('Generating QR code for vehicleId:', vehicleId);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'fetch_vehicle_details.php', true); // Adjusted path if needed
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                try {
                    const vehicleDetails = JSON.parse(xhr.responseText);
                    if (vehicleDetails && vehicleDetails.ParkingNumber) {
                        const qrContainer = document.getElementById('qrcode');
                        qrContainer.innerHTML = '';

                        const vehicleData = `
                            Parking Number: ${vehicleDetails.ParkingNumber}
                            Owner Name: ${vehicleDetails.OwnerName}
                            Vehicle Reg Number: ${vehicleDetails.RegistrationNumber}
                        `;

                        const qrcode = new QRCode(qrContainer, {
                            text: vehicleData,
                            width: 256,
                            height: 256,
                        });

                        // Add a small delay to ensure QR code is generated before attempting to download it
                        setTimeout(() => {
                            const qrCanvas = qrContainer.querySelector('canvas');
                            if (qrCanvas) {
                                const downloadBtn = document.getElementById('downloadQR');
                                downloadBtn.style.display = 'block';
                                downloadBtn.onclick = () => downloadQRCode(qrCanvas);
                            }
                        }, 500);

                        console.log('QR code generated successfully');
                    } else {
                        console.error('Invalid vehicle data:', vehicleDetails);
                    }
                } catch (e) {
                    console.error('Failed to parse vehicle data:', e);
                }
            } else if (xhr.readyState === 4) {
                console.error('Failed to fetch vehicle data, status:', xhr.status);
            }
        };
        xhr.send(`vid=${vehicleId}`);
    }

    function downloadQRCode(qrCanvas) {
        const dataUrl = qrCanvas.toDataURL('image/png');
        const link = document.createElement('a');
        link.href = dataUrl;
        link.download = 'qr_code.png';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
</script>

</body>
</html>
<?php } ?>
