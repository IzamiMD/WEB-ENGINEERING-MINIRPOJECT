<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsuid']==0)) {
    header('location:logout.php');
} else{
    if(isset($_GET['vid'])){
        $vehicleId = $_GET['vid'];
        // Delete vehicle from database based on $vehicleId
        $query = "DELETE FROM tblvehicle WHERE ID = '$vehicleId'";
        $result = mysqli_query($con, $query);
        if($result){
            echo "Vehicle deleted successfully.";
        } else {
            echo "Error deleting vehicle.";
        }
    }
}
?>
