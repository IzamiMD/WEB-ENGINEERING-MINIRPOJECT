<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['vpmsaid']) == 0) {
    header('location:user-confirmation.php');
} else {
    // Ensure this is only processed for admin users
    if (isset($_POST['submit'])) {
        $parkingnumber = mt_rand(100000000, 999999999);
        $catename = $_POST['catename'];
        $vehcomp = $_POST['vehcomp'];
        $vehreno = $_POST['vehreno'];
        $ownername = $_POST['ownername'];
        $ownercontno = $_POST['ownercontno'];
        $enteringtime = $_POST['enteringtime'];

        $query = mysqli_query($con, "insert into tblvehicle(ParkingNumber, VehicleCategory, VehicleCompanyname, RegistrationNumber, OwnerName, OwnerContactNumber) value('$parkingnumber', '$catename', '$vehcomp', '$vehreno', '$ownername', '$ownercontno')");
        if ($query) {
            echo "<script>alert('Vehicle Entry Detail has been added');</script>";
            echo "<script>window.location.href ='manage-incomingvehicle.php'</script>";
        } else {
            echo "<script>alert('Something Went Wrong. Please try again.');</script>";
        }
    }

    // Start session and check if the user is logged in as a student
    if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'student') {
        header("location: login.php");
        exit;
    }
    $user_id = $_SESSION['user_id']; // Assuming user_id is stored in the session upon login

    $con->close();
}
?>
<!doctype html>
<html class="no-js" lang="">
<head>
    <title>VPMS - Add Vehicle</title>
    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="../admin/assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../admin/assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/jqvmap@1.5.1/dist/jqvmap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/weathericons@2.1.0/css/weather-icons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.css" rel="stylesheet" />
  
    <!-- BOOK PARKING LINK -->
    <link rel="stylesheet" href="user-css/booking_styles.css">
    <script defer src="../js/book_parking.js"></script>
    <script src="../assets/qrcodejs-master/qrcode.min.js"></script>
    <!-- BOOK PARKING LINK -->
  
    <style>
        #weatherWidget .currentDesc { color: #ffffff!important; }
        .traffic-chart { min-height: 335px; }
        #flotPie1 { height: 150px; }
        #flotPie1 td { padding: 3px; }
        #flotPie1 table { top: 20px!important; right: -10px!important; }
        .chart-container { display: table; min-width: 270px; text-align: left; padding-top: 10px; padding-bottom: 10px; }
        #flotLine5 { height: 105px; }
        #flotBarChart { height: 150px; }
        #cellPaiChart { height: 160px; }
    </style> 
</head>
<body>
    <?php include_once('includes/sidebar.php'); ?>
    <?php include_once('includes/header.php'); ?>
    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Dashboard</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard.php">Dashboard</a></li>
                                <li class="active">Book Parking</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>BOOK </strong> PARKING (STUDENT)
                        </div>
                        <div class="card-body card-block">
                            <div class="book-parking">
                                <form id="bookingForm">
                                    <label for="parkingArea">Select Parking Area</label>
                                    <select id="parkingArea" name="parkingArea">
                                        <option value="lotA1">Parking Lot A1</option>
                                        <option value="lotA2">Parking Lot A2</option>
                                        <option value="lotA3">Parking Lot A3</option>
                                        <option value="lotA4">Parking Lot A4</option>
                                        <option value="lotB1">Parking Lot B1</option>
                                        <option value="lotB2">Parking Lot B2</option>
                                        <option value="lotB3">Parking Lot B3</option>
                                    </select>
                                    <br>
                                    <label for="slotAvailable">Slot Available</label>
                                    <select id="slotAvailable" name="slotAvailable">
                                        <option value="slot1">Slot 1</option>
                                        <option value="slot2">Slot 2</option>
                                        <option value="slot3">Slot 3</option>
                                        <option value="slot4">Slot 4</option>
                                        <option value="slot5">Slot 5</option>
                                        <option value="slot6">Slot 6</option>
                                        <option value="slot7">Slot 7</option>
                                        <option value="slot8">Slot 8</option>
                                        <option value="slot9">Slot 9</option>
                                        <option value="slot10">Slot 10</option>
                                    </select>
                                    <br>
                                    <div class="row form-group">
                                        <div class="col col-md-3"><label for="timeSlot" class="form-control-label">Time Slot</label></div>
                                        <div class="col-12 col-md-9">
                                            <select id="timeSlot" name="time_slot" class="form-control" required>
                                                <option value="08:00:00">08:00:00</option>
                                                <option value="09:00:00">09:00:00</option>
                                                <option value="10:00:00">10:00:00</option>
                                                <option value="11:00:00">11:00:00</option>
                                                <option value="12:00:00">12:00:00</option>
                                                <option value="13:00:00">13:00:00</option>
                                                <option value="14:00:00">14:00:00</option>
                                                <option value="15:00:00">15:00:00</option>
                                                <option value="16:00:00">16:00:00</option>
                                                <option value="17:00:00">17:00:00</option>
                                                <option value="18:00:00">18:00:00</option>
                                                <option value="19:00:00">19:00:00</option>
                                                <option value="20:00:00">20:00:00</option>
                                                <option value="21:00:00">21:00:00</option>
                                            </select>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="time-container">
                                        <div>
                                            <label for="startTime">Start Date</label>
                                            <input type="date" id="startTime" name="startTime" required>
                                        </div>
                                        <div>
                                            <label for="endTime">End Date</label>
                                            <input type="date" id="endTime" name="endTime" required>
                                        </div>
                                    </div>
                                    <br>
                                    <button type="submit" id="bookButton">Book Now</button>
                                    <button type="button" id="updateButton" style="display:none;">Update</button>
                                </form>
                                <div id="bookingDetails">
                                    <h3>Booking Details</h3>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Booking ID</th>
                                                <th>Parking Area</th>
                                                <th>Slot Available</th>
                                                <th>Start Time</th>
                                                <th>End Time</th>
                                                <th>Action</th>
                                                <th>Confirmation</th>
                                            </tr>
                                        </thead>
                                        <tbody id="bookingsTableBody">
                                            <!-- Booked parking details will be displayed here -->
                                        </tbody>
                                    </table>
                                    <div id="qrContainer">
                                        <div id="qrcode"></div>
                                        <button id="downloadQR" style="display: none; margin-top: 10px;">Download QR Code</button>
                                        <button id="checkoutButton" style="display: none; margin-top: 10px;">Checkout</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- .animated -->
            </div><!-- .content -->
        </div><!-- /#right-panel -->
        <div class="clearfix"></div>
        <?php include_once('includes/footer.php'); ?>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
