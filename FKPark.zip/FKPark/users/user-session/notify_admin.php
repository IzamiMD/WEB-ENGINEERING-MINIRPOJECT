<?php
session_start();
include('../includes/dbconnection.php');

$bookingId = $_POST['bookingId'];

$sql = "UPDATE ParkingBooking SET Confirmed = 2 WHERE Booking_ID = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $bookingId);

$response = [];
if ($stmt->execute()) {
    // Assume you have a function to notify the admin, e.g., via email or another method.
    // notifyAdmin($bookingId);
    $response['success'] = true;
} else {
    $response['success'] = false;
}

$stmt->close();
$con->close();

echo json_encode($response);
?>
