<?php
session_start();
include('../includes/dbconnection.php');

$user_id = $_SESSION['user_id']; // Assuming user_id is stored in session

$sql = "SELECT Booking_ID, parkingArea, slotAvailable, StartTime, EndTime, Confirmed FROM parkingbooking WHERE user_id = ? ORDER BY StartTime ASC";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$bookings = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $confirmationStatus = '';
        if ($row['Confirmed'] == 1) {
            $confirmationStatus = '&#10004;'; // Check mark
        } elseif ($row['Confirmed'] == 2) {
            $confirmationStatus = 'Pending';
        } else {
            $confirmationStatus = '&#10060;'; // X mark
        }

        $actions = "
            <button onclick='generateQRCode({$row['Booking_ID']})'>Generate QR</button>
            <button onclick='editBooking({$row['Booking_ID']})'>Edit</button>
            <button onclick='deleteBooking({$row['Booking_ID']})'>Delete</button>
        ";

        if ($row['Confirmed'] == 1) {
            $actions .= "<button onclick='cancelBooking({$row['Booking_ID']})'>Cancel</button>";
        }

        $bookings[] = array(
            'Booking_ID' => $row['Booking_ID'],
            'parkingArea' => $row['parkingArea'],
            'slotAvailable' => $row['slotAvailable'],
            'StartTime' => date("Y-m-d", strtotime($row['StartTime'])), // Format StartTime to date only
            'EndTime' => date("Y-m-d", strtotime($row['EndTime'])),     // Format EndTime to date only
            'Actions' => $actions,
            'Confirmation' => $confirmationStatus,
        );
    }
}

$stmt->close();
$con->close();

echo json_encode($bookings);
?>
