<?php
session_start();
include('../includes/dbconnection.php');

$bookingId = $_POST['bookingId'];
$parkingArea = $_POST['parkingArea'];
$slotAvailable = $_POST['slotAvailable'];
$startTime = $_POST['startTime'];
$endTime = $_POST['endTime'];
$user_id = $_SESSION['user_id']; // Assuming user_id is stored in session

$sql = "UPDATE ParkingBooking SET parkingArea=?, slotAvailable=?, StartTime=?, EndTime=? WHERE Booking_ID=? AND user_id=?";
$stmt = $con->prepare($sql);
$stmt->bind_param("ssssii", $parkingArea, $slotAvailable, $startTime, $endTime, $bookingId, $user_id);

if ($stmt->execute()) {
    echo "Booking updated successfully";
} else {
    echo "Error updating booking: " . $stmt->error;
}

$stmt->close();
$con->close();
?>