<?php
session_start();

// Ensure error reporting is configured before any output
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('../includes/dbconnection.php');

header('Content-Type: application/json');

$response = array('success' => false, 'message' => 'Invalid request');

if (isset($_POST['parkingArea']) && isset($_POST['slotAvailable']) && isset($_POST['startTime']) && isset($_POST['endTime']) && isset($_POST['time_slot'])) {
    $parkingArea = $_POST['parkingArea'];
    $slotAvailable = $_POST['slotAvailable'];
    $startTime = $_POST['startTime'];
    $endTime = $_POST['endTime'];
    $time_slot = $_POST['time_slot'];

    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id']; // Assuming user_id is stored in session
        $staff_id = null;
    } elseif (isset($_SESSION['staff_id'])) {
        $staff_id = $_SESSION['staff_id']; // Assuming staff_id is stored in session
        $user_id = null;
    } else {
        $response['message'] = 'User not logged in';
        echo json_encode($response);
        exit;
    }

    // Generate a random booking ID
    $bookingID = rand(10000, 99999);

    // Extract the numeric part of the slotAvailable to determine the parking_id
    $parking_id = (int) filter_var($slotAvailable, FILTER_SANITIZE_NUMBER_INT);

    $sql = "INSERT INTO parkingbooking (Booking_ID, parkingArea, slotAvailable, StartTime, EndTime, Confirmed, user_id, staff_id, parking_id, time_slot) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, ?)";
    $stmt = $con->prepare($sql);
    if ($stmt === false) {
        $response['message'] = 'Prepare failed: ' . htmlspecialchars($con->error);
        echo json_encode($response);
        exit;
    }

    $stmt->bind_param("issssiiis", $bookingID, $parkingArea, $slotAvailable, $startTime, $endTime, $user_id, $staff_id, $parking_id, $time_slot);

    if ($stmt->execute()) {
        $response = array('success' => true, 'bookingID' => $bookingID);
    } else {
        $response['message'] = 'Execute failed: ' . htmlspecialchars($stmt->error);
    }

    $stmt->close();
} else {
    $response['message'] = 'Missing required fields';
}

$con->close();
echo json_encode($response);
?>
