<?php
session_start();
include('../includes/dbconnection.php');

$bookingId = $_POST['bookingId'];
$user_id = $_SESSION['user_id']; // Assuming user_id is stored in session

$sql = "UPDATE ParkingBooking SET Confirmed=0 WHERE Booking_ID=? AND user_id=?";
$stmt = $con->prepare($sql);
$stmt->bind_param("ii", $bookingId, $user_id);

if ($stmt->execute()) {
    echo "Booking cancelled successfully";
} else {
    echo "Error cancelling booking: " . $stmt->error;
}

$stmt->close();
$con->close();
?>