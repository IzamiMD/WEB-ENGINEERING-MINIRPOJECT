<?php
session_start();
include('../includes/dbconnection.php');

$bookingId = $_GET['bookingId'];

$sql = "SELECT Booking_ID, parkingArea, slotAvailable, StartTime, EndTime, Confirmed FROM ParkingBooking WHERE Booking_ID = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $bookingId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $booking = $result->fetch_assoc();
    echo json_encode($booking);
} else {
    echo json_encode([]);
}

$stmt->close();
$con->close();
?>
