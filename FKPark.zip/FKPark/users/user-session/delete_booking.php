<?php
session_start();
include('../includes/dbconnection.php');

$bookingId = $_POST['bookingId'];
$user_id = $_SESSION['user_id']; // Assuming user_id is stored in session

$sql = "DELETE FROM ParkingBooking WHERE Booking_ID=? AND user_id=?";
$stmt = $con->prepare($sql);
$stmt->bind_param("ii", $bookingId, $user_id);

if ($stmt->execute()) {
    echo "Booking deleted successfully";
} else {
    echo "Error deleting booking: " . $stmt->error;
}

$stmt->close();
$con->close();
?>