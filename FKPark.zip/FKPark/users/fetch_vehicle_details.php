<?php
include('includes/dbconnection.php');

if (isset($_POST['vid'])) {
    $vehicleId = $_POST['vid'];
    $query = mysqli_query($con, "SELECT * FROM tblvehicle WHERE ID = '$vehicleId'");
    $row = mysqli_fetch_assoc($query);
    echo json_encode($row);
}
?>
