<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="device-width, initial-scale=1.0">
    <title>Summon Information</title>
    <link rel="stylesheet" type="text/css" href="../staff/css/table.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="../assets/qrcodejs-master/qrcode.js"></script> 
</head>
<body>
            <main class="table" id="customers_table">
                <section class="table__header">
                    <h1>Summon Information</h1>
                    <div class="input-group">
                        <input type="search" placeholder="Search Data...">
                        <img src="images/search.jpg" alt="">
                    </div>
                    
                    <button onclick="goBack()" class="go-back-btn">Go Back</button>
                </section>
                <section class="table__body">
                    <table>
                        <thead>
                            <tr>
                                <th> Summon Id <span class="icon-arrow">&UpArrow;</span></th>
                                <th> User ID <span class="icon-arrow">&UpArrow;</span></th>
                                <th> Vehicle ID <span class="icon-arrow">&UpArrow;</span></th>
                                <th> Demerit Point <span class="icon-arrow">&UpArrow;</span></th>
                                <th> Type Car <span class="icon-arrow">&UpArrow;</span></th>
                                <th colspan="4" style="text-align: center"> Action <span class="icon-arrow">&UpArrow;</span></th>
                            </tr>
                        </thead>
                        <tbody id="summonData">
                            <!-- Data will be inserted here by JavaScript -->
                        </tbody>
                    </table>
                </section>
            </main>
        
    
    <div id="qrModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div id="qrcode"></div>
        </div>
    </div>
    <script src="js/fullscreen.js"></script>
    <script src="js/tablesort.js"></script>
    <script src="js/tableUser.js"></script>
    <script>
        function goBack() {
            window.history.back();
        }
    </script>
</body>
</html>
