<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsuid']==0)) {
    header('location:logout.php');
} else{
    if(isset($_POST['submit'])) {
        $vehicleId = $_POST['vehicleId'];
        $parkingNumber = $_POST['parkingNumber'];
        $ownerName = $_POST['ownerName'];

        $query = "UPDATE tblvehicle SET ParkingNumber='$parkingNumber', OwnerName='$ownerName' WHERE ID='$vehicleId'";
        $result = mysqli_query($con, $query);

        if($result) {
            echo "<script>alert('Vehicle details updated successfully');</script>";
            echo "<script>window.location.href='view-vehicle.php?vid=$vehicleId'</script>";
        } else {
            echo "<script>alert('Failed to update vehicle details');</script>";
        }
    }
}
?>
