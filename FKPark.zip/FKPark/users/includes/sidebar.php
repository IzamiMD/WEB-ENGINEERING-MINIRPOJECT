 <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"><i class="menu-icon fa fa-laptop"></i>User Dashboard </a>
                    </li>
                    
                    <li>
                        <a href="view-vehicle.php"> <i class="menu-icon ti-truck"></i>View My Vehicle </a>
                    </li>
                    <li>
                        <a href="add-vehicle.php"> <i class="menu-icon ti-truck"></i>Register Vehicle </a>
                    </li>
                    <li>
                        <a href="ViewParkingStudent.php"> <i class="menu-icon ti-user"></i>View Parking </a>
                    </li>
                    <li>
                        <a href="user-booking.php"> <i class="menu-icon ti-user"></i>Book Parking </a>
                    </li>
                    <li>
                        <a href="SummonInformationUser.php"> <i class="menu-icon ti-user"></i>Summon Information</a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>