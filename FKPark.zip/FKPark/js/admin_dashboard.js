// Function to fetch data and update the dashboard
function fetchDataAndUpdateDashboard(parkingArea = 'all') {
    fetch(`../admin/admin-dashboard/fetch_parking_data.php?parkingArea=${parkingArea}`)
        .then(response => response.json())
        .then(data => {
            const totalVehicleParked = data.totalVehicleParked;
            const totalParkingAvailable = data.totalParkingAvailable;
            const totalParkingBooked = data.totalParkingBooked;

            // Update the dashboard metrics
            document.getElementById('total-vehicle-parked').textContent = totalVehicleParked;
            document.getElementById('total-parking-available').textContent = totalParkingAvailable;
            document.getElementById('total-parking-booked').textContent = totalParkingBooked;

            // Update the chart
            const ctx = document.getElementById('parkingChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Total Vehicle Parked', 'Total Parking Available', 'Total Parking Booked'],
                    datasets: [{
                        label: '# of Slots',
                        data: [totalVehicleParked, totalParkingAvailable, totalParkingBooked],
                        backgroundColor: [
                            'rgba(75, 192, 192, 0.2)',
                            'rgba(54, 162, 235, 0.2)',
                            'rgba(255, 206, 86, 0.2)'
                        ],
                        borderColor: [
                            'rgba(75, 192, 192, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Load parking details for modals
            loadParkingDetails(parkingArea);
            loadParkingBookedDetails(parkingArea);
        })
        .catch(error => console.error('Error fetching data:', error));
}

// Function to load parking details
function loadParkingDetails(parkingArea = 'all') {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `../admin/admin-dashboard/get_parking_details.php?parkingArea=${parkingArea}`, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById('parking-details').innerHTML = xhr.responseText;
        }
    };
    xhr.send();
}

// Function to load booked parking details
function loadParkingBookedDetails(parkingArea = 'all') {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `../admin/admin-dashboard/get_parking_booked_details.php?parkingArea=${parkingArea}`, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById('parking-booked-details').innerHTML = xhr.responseText;
        }
    };
    xhr.send();
}

// Function to show the selected section
function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.style.display = 'none';
    });
    document.getElementById(sectionId).style.display = 'block';
}

// Function to load bookings to approve
function loadBookingsToApprove() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `../admin/admin-dashboard/get_bookings_to_approve.php`, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const data = JSON.parse(xhr.responseText);
            const tableBody = document.getElementById('approveBookingsTableBody');
            tableBody.innerHTML = ''; // Clear the table body

            data.forEach(booking => {
                const row = document.createElement('tr');

                row.innerHTML = `
                    <td>${booking.Booking_ID}</td>
                    <td>${booking.parkingArea}</td>
                    <td>${booking.slotAvailable}</td>
                    <td>${booking.StartTime}</td>
                    <td>${booking.EndTime}</td>
                    <td><button onclick="approveBooking(${booking.Booking_ID})">Approve</button></td>
                `;

                tableBody.appendChild(row);
            });
        }
    };
    xhr.send();
}

// Function to approve booking
function approveBooking(bookingId) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `../admin/admin-dashboard/approve_booking.php`, true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.responseText);
            loadBookingsToApprove();
        }
    };
    xhr.send(`bookingId=${bookingId}`);
}

// Logout function
function logout() {
    alert('Logging out...');
}

// Call the functions on page load
window.onload = () => {
    showSection('admin-dashboard');
    fetchDataAndUpdateDashboard();
    loadBookingsToApprove();
}
