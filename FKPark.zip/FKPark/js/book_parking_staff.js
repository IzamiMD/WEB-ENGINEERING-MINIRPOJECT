let editMode = false;
let currentBookingId = null;

document.getElementById('bookingForm').addEventListener('submit', function(event) {
    event.preventDefault();
    if (editMode) {
        updateBooking(currentBookingId);
    } else {
        bookParking();
    }
});

document.getElementById('updateButton').addEventListener('click', function(event) {
    event.preventDefault();
    updateBooking(currentBookingId);
});

document.addEventListener('DOMContentLoaded', function() {
    loadBookings();

    const checkoutButton = document.getElementById('checkoutButton');
    if (checkoutButton) {
        checkoutButton.addEventListener('click', function() {
            const bookingId = document.getElementById('bookingId').textContent; // Obtain the bookingId appropriately
            window.location.href = `staff-confirmation.php?bookingId=${bookingId}`;
        });
    }
});

function bookParking() {
    const parkingArea = document.getElementById('parkingArea').value;
    const slotAvailable = document.getElementById('slotAvailable').value;
    const startTime = document.getElementById('startTime').value;
    const endTime = document.getElementById('endTime').value;
    const timeSlot = document.getElementById('timeSlot').value;

    if (!parkingArea || !slotAvailable || !startTime || !endTime || !timeSlot) {
        alert('Please fill in all fields');
        return;
    }

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "staff-session/book_parking.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            if (response.success) {
                alert('Booking successful');
                loadBookings();
            } else {
                alert('Booking failed: ' + response.error);
            }
        }
    };
    xhr.send(`parkingArea=${encodeURIComponent(parkingArea)}&slotAvailable=${encodeURIComponent(slotAvailable)}&startTime=${encodeURIComponent(startTime)}&endTime=${encodeURIComponent(endTime)}&time_slot=${encodeURIComponent(timeSlot)}`);
}

function loadBookings() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'staff-session/get_bookings.php', true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            try {
                const response = JSON.parse(xhr.responseText);
                let bookingsHtml = '';
                response.forEach(booking => {
                    let confirmationStatus;
                    let cancelButton = '';
                    switch (booking.Confirmed) {
                        case 0:
                            confirmationStatus = "X"; // Not notified
                            break;
                        case 1:
                            confirmationStatus = "✔"; // Approved
                            cancelButton = `<button onclick="cancelBooking(${booking.Booking_ID})">Cancel</button>`;
                            break;
                        case 2:
                            confirmationStatus = "Pending"; // Pending approval
                            break;
                        default:
                            confirmationStatus = "X"; // Default case
                    }

                    // Format the StartTime and EndTime to only show the date part
                    const startDate = new Date(booking.StartTime).toISOString().split('T')[0];
                    const endDate = new Date(booking.EndTime).toISOString().split('T')[0];

                    bookingsHtml += `
                        <tr>
                            <td>${booking.Booking_ID}</td>
                            <td>${booking.parkingArea}</td>
                            <td>${booking.slotAvailable}</td>
                            <td>${startDate}</td>
                            <td>${endDate}</td>
                            <td>
                                <button onclick="editBooking(${booking.Booking_ID})">Edit</button>
                                <button onclick="deleteBooking(${booking.Booking_ID})">Delete</button>
                                <button onclick="generateQRCode(${booking.Booking_ID})">Generate QR</button>
                                ${cancelButton}
                            </td>
                            <td class='confirmation-column'>${confirmationStatus}</td>
                        </tr>
                    `;
                });
                document.getElementById('bookingsTableBody').innerHTML = bookingsHtml;
            } catch (e) {
                console.error("Failed to parse JSON response: ", e);
            }
        } else if (xhr.readyState === 4) {
            console.error("Failed to load bookings: ", xhr.statusText);
        }
    };
    xhr.send();
}


function deleteBooking(bookingId) {
    if (!confirm('Are you sure you want to delete this booking?')) return;

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "staff-session/delete_booking.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.responseText);
            loadBookings();
        }
    };
    xhr.send(`bookingId=${bookingId}`);
}

function cancelBooking(bookingId) {
    if (confirm('Are you sure you want to cancel this booking?')) {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'staff-session/cancel_booking.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                alert('Booking cancelled successfully');
                loadBookings(); // Reload to update the UI
            }
        };
        xhr.send(`bookingId=${bookingId}`);
    }
}

function editBooking(bookingId) {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", `staff-session/get_specific_booking.php?bookingId=${bookingId}`, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const booking = JSON.parse(xhr.responseText);
            document.getElementById('parkingArea').value = booking.parkingArea;
            document.getElementById('slotAvailable').value = booking.slotAvailable;
            document.getElementById('startTime').value = booking.StartTime;
            document.getElementById('endTime').value = booking.EndTime;
            document.getElementById('timeSlot').value = booking.time_slot;

            document.getElementById('bookButton').style.display = 'none';
            document.getElementById('updateButton').style.display = 'block';

            editMode = true;
            currentBookingId = bookingId;
        }
    };
    xhr.send();
}

function updateBooking(bookingId) {
    const parkingArea = document.getElementById('parkingArea').value;
    const slotAvailable = document.getElementById('slotAvailable').value;
    const startTime = document.getElementById('startTime').value;
    const endTime = document.getElementById('endTime').value;
    const timeSlot = document.getElementById('timeSlot').value;

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "staff-session/update_booking.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.responseText);
            loadBookings();
            document.getElementById('bookingForm').reset();
            document.getElementById('bookButton').style.display = 'block';
            document.getElementById('updateButton').style.display = 'none';

            editMode = false;
            currentBookingId = null;
        }
    };
    xhr.send(`bookingId=${bookingId}&parkingArea=${parkingArea}&slotAvailable=${slotAvailable}&startTime=${startTime}&endTime=${endTime}&time_slot=${timeSlot}`);
}

function generateQRCode(bookingId) {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", `staff-session/get_specific_booking.php?bookingId=${bookingId}`, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            try {
                const booking = JSON.parse(xhr.responseText);
                if (booking && booking.Booking_ID) {
                    const qrContainer = document.getElementById('qrcode');
                    qrContainer.innerHTML = '';

                    const bookingDetails = `
                        Booking ID: ${booking.Booking_ID}
                        Parking Area: ${booking.parkingArea}
                        Slot Available: ${booking.slotAvailable}
                        Start Time: ${booking.StartTime}
                        End Time: ${booking.EndTime}
                    `;

                    const qrcode = new QRCode(qrContainer, {
                        text: bookingDetails,
                        width: 256,
                        height: 256,
                    });

                    // Add a small delay to ensure QR code is generated before attempting to download it
                    setTimeout(() => {
                        const qrCanvas = qrContainer.querySelector('canvas');
                        if (qrCanvas) {
                            const downloadBtn = document.getElementById('downloadQR');
                            downloadBtn.style.display = 'block';
                            downloadBtn.onclick = () => downloadQRCode(qrCanvas);

                            const checkoutBtn = document.getElementById('checkoutButton');
                            if (booking.Confirmed == 0) { // Show only if not confirmed
                                checkoutBtn.style.display = 'block';
                            } else {
                                checkoutBtn.style.display = 'none';
                            }
                            checkoutBtn.onclick = () => window.location.href = `staff-confirmation.php?bookingId=${booking.Booking_ID}`;
                        }
                    }, 500);

                    console.log('QR code generated successfully');
                } else {
                    console.error('Invalid booking data:', booking);
                }
            } catch (e) {
                console.error('Failed to parse booking data:', e);
            }
        } else if (xhr.readyState === 4) {
            console.error('Failed to fetch booking data, status:', xhr.status);
        }
    };
    xhr.send();
}

function downloadQRCode(qrCanvas) {
    const dataUrl = qrCanvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = 'qr_code.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
