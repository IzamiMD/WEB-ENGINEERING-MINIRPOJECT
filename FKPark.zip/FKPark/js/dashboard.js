document.addEventListener('DOMContentLoaded', function() {
    fetch('php/fetch_total_students.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                console.error('Error from PHP:', data.error);
                document.getElementById('totalStudents').innerText = 'Error';
            } else {
                document.getElementById('totalStudents').innerText = data.total;
            }
        })
        .catch(error => {
            console.error('Error fetching total students:', error);
            document.getElementById('totalStudents').innerText = 'Error';
        });
});
