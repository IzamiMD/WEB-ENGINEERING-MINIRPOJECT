document.addEventListener('DOMContentLoaded', function() {
    const bookingId = new URLSearchParams(window.location.search).get('bookingId');
    if (bookingId) {
        loadBookingDetails(bookingId);
    }

    document.getElementById('notifyButton').addEventListener('click', function() {
        notifyAdmin(bookingId);
    });
});

function loadBookingDetails(bookingId) {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", `user-session/fetch_booking_details.php?bookingId=${bookingId}`, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            try {
                const booking = JSON.parse(xhr.responseText);
                if (booking) {
                    document.getElementById('bookingId').textContent = booking.Booking_ID;
                    document.getElementById('parkingArea').textContent = booking.parkingArea;
                    document.getElementById('slotAvailable').textContent = booking.slotAvailable;
                    document.getElementById('startTime').textContent = booking.StartTime;
                    document.getElementById('endTime').textContent = booking.EndTime;
                } else {
                    alert('No booking details found.');
                }
            } catch (e) {
                alert('Failed to parse booking details');
            }
        } else if (xhr.readyState === 4) {
            alert('Failed to fetch booking details');
        }
    };
    xhr.send();
}

function notifyAdmin(bookingId) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "user-session/notify_admin.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            try {
                const response = JSON.parse(xhr.responseText);
                if (response.success) {
                    alert('Admin notified successfully.');
                    window.location.href = 'user-booking.php';
                } else {
                    alert('Failed to notify admin.');
                }
            } catch (e) {
                alert('Failed to parse response');
            }
        } else if (xhr.readyState === 4) {
            alert('Failed to notify admin.');
        }
    };
    xhr.send(`bookingId=${bookingId}`);
}
